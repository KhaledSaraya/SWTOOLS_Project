package SWTOOLS;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import java.util.List;

@Stateless
public class Restaurant_Service {

    @PersistenceContext(unitName = "YourPersistenceUnitName")
    private EntityManager entityManager;

    public void addRestaurant(Restaurant restaurant) {
        entityManager.persist(restaurant);
    }

    public void updateRestaurant(Restaurant restaurant) {
        entityManager.merge(restaurant);
    }

    public void removeRestaurant(long restaurantId) {
        Restaurant restaurant = entityManager.find(Restaurant.class, restaurantId);
        if (restaurant != null) {
            entityManager.remove(restaurant);
        }
    }
    
    public Restaurant getRestaurantById(long restaurantId) {
        return entityManager.find(Restaurant.class, restaurantId);
    }

    public List<Restaurant> getAllRestaurants() {
        TypedQuery<Restaurant> query = entityManager.createQuery("SELECT r FROM Restaurant r", Restaurant.class);
        List<Restaurant> allres = query.getResultList();
       
       return allres;
    }

    public void createMenu(long restaurantId, Meal[] meals ) {
        Restaurant restaurant = entityManager.find(Restaurant.class, restaurantId);
        if (restaurant != null) 
        {
        	meals = restaurant.getList_of_meals();
            
            entityManager.persist(meals);
        }
        }
    
    public void editRestaurantMenu(long restaurantId, Meal[] newMeals) {
        Restaurant restaurant = entityManager.find(Restaurant.class, restaurantId);
        if (restaurant != null) {
                restaurant.setList_of_meals(newMeals);
                entityManager.merge(restaurant);
            }
        }
    
    public void generateRestaurantReport(long restaurantId) {
        // Calculate total earnings
        TypedQuery<Order> OQuery = entityManager.createQuery("SELECT SUM(o.total_account) FROM Order o WHERE o.order_fk_restaurantId = :restaurantId AND o.order_status = :delivered", Order.class);
        OQuery.setParameter("order_fk_restaurantId", restaurantId);
        OQuery.setParameter("order_status", "delivered");
//       double totalEarnings = OQuery.getSingleResult();
////        if (totalEarnings == null) {
////            totalEarnings = 0.0;
////        }

        // Calculate number of completed orders
        TypedQuery<Order>  completedOrdersQuery = entityManager.createQuery("SELECT COUNT(o) FROM Order o WHERE o.restaurant.id = :restaurantId AND o.status = :delivered",Order.class);
        completedOrdersQuery.setParameter("order_fk_restaurantId", restaurantId);
        completedOrdersQuery.setParameter("order_status", "delivered");
//        Long completedOrdersCount = (Long) completedOrdersQuery.getSingleResult();
//        if (completedOrdersCount == null) {
//            completedOrdersCount = 0L;
//        }

        // Calculate number of canceled orders
        TypedQuery<Order> canceledOrdersQuery = entityManager.createQuery("SELECT COUNT(o) FROM Order o WHERE o.restaurant.id = :restaurantId AND o.status = :canceled",Order.class);
        canceledOrdersQuery.setParameter("order_fk_restaurantId", restaurantId);
        canceledOrdersQuery.setParameter("order_status", "canceled");
//        Long canceledOrdersCount = (Long) canceledOrdersQuery.getSingleResult();
//        if (canceledOrdersCount == null) {
//            canceledOrdersCount = 0L;
//        }

        // Print the restaurant report
        System.out.println("Restaurant Report:");
        System.out.println("Restaurant ID: " + restaurantId);
        System.out.println("Total Earnings: " + OQuery.getSingleResult());
        System.out.println("Number of Completed Orders: " + completedOrdersQuery.getSingleResult());
        System.out.println("Number of Canceled Orders: " + canceledOrdersQuery.getSingleResult());

    }


};