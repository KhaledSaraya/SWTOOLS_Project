package SWTOOLS;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import java.util.Date;
import java.util.List;
public class Customer_Service {


	    @PersistenceContext(unitName = "YourPersistenceUnitName")
	    private EntityManager entityManager;

//	    public void placeOrder(Order order) {
//	        entityManager.persist(order);
//	    }
//
//	    public void cancelOrder(long orderId) {
//	        Order order = entityManager.find(Order.class, orderId);
//	        if (order != null && order.getStatus() != OrderStatus.CANCELED) {
//	            order.setStatus(OrderStatus.CANCELED);
//	            entityManager.merge(order);
//	        }
//	    }

	    public Order getOrderById(long orderId) {
	        return entityManager.find(Order.class, orderId);
	    }

	    public List<Order> getAllOrders() {
	        Query query = entityManager.createQuery("SELECT o FROM Order o");
	        return query.getResultList();
	    }

//	    public List<Order> getOrdersByCustomerId(long customerId) {
//	        Query query = entityManager.createQuery("SELECT o FROM Order o WHERE o.customer.id = :customerId");
//	        query.setParameter("customerId", customerId);
//	        return query.getResultList();
//	    }
	    
	    public List<Restaurant> getAllRestaurants() {
	        TypedQuery<Restaurant> query = entityManager.createQuery("SELECT r FROM Restaurant r", Restaurant.class);
	        List<Restaurant> allres = query.getResultList();
	       
	       return allres;
	    }
	    
	    public void createOrder(int UserId, int restaurantid, Meal[] Meals_Ordered, Runner R,double deliveryFees, String runnerName) {
	        // Create a new order
	    	Restaurant res = new Restaurant();
	        Order order = new Order();
//	        order.
	        order.setOrder_fk_restaurantId(restaurantid);
//	        order.setOrderDate(new Date());
	        order.setOrder_status("delivered");

	        // Add order items
	        res.setList_of_meals(Meals_Ordered);

	        // Calculate total receipt value
	        double totalReceiptValue = calculateTotalReceiptValue(Meals_Ordered, deliveryFees);
	        order.setTotalReceiptValue(totalReceiptValue);

	        // Set delivery fees and runner name
	        R.setDelivery_fees(deliveryFees);
	        R.setRunner_Name(runnerName);
	        
	        order.setDeliveryFees(deliveryFees);
	        order.setRunnerName(runnerName);

	        // Save the order to the database
	        entityManager.persist(order);
	        entityManager.persist(R);
	    }

		private double calculateTotalReceiptValue(Meal[] meals_Ordered, double deliveryFees) {
			// TODO Auto-generated method stub
			return 0;
		}

		private void setOrder_fk_restaurantId(int restaurantid) {
			// TODO Auto-generated method stub
			
		}


	};

